---
layout: default
title: NHL In-depth analysis
---
## About

Kevin Chelfi, Etudiant Maitrise

## Contact

Link to our [repo](https://github.com/herfoum3/nhl_project "github repo").
